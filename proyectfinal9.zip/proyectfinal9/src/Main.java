import java.util.*;

// Definimos nuestra clase principal
class StudentManagementSystem {
    private static final int NUM_TRIMESTRES = 3;
    private static HashMap<String, HashMap<String, int[]>> notasEstudiantes = new HashMap<>();

    // Definimos un método para calcular el promedio de tres notas
    public static float calcularPromedio(int[] notas) {
        int suma = 0;
        for (int nota : notas) {
            suma += nota;
        }
        return (float) suma / NUM_TRIMESTRES;
    }
    // Definimos el método principal que se ejecuta cuando se inicia nuestro programa
    public static void main(String[] args) {
        //creamos el objeto Scanner que permitirá la interactividad del usuario con el programa
        Scanner scanner = new Scanner(System.in);

        // Creamos estructuras de datos para almacenar información necesaria
        HashMap<String, String> materiasHorarios = new HashMap<>();

        // Definimos una variable para control del flujo del programa
        String continuarEleccion = "s";

        System.out.println("Bienvenido al Sistema de Gestión de Estudiantes del instituto Hermán Hollerith para docentes del Área de Informática");
        System.out.println("=====================================================");
        //comenzamos un bucle do while para tener una condición común de cierre para cada case
        do {
            System.out.println("\nElija una opción, por favor:");
            System.out.println("1. Ingresar alumnos");
            System.out.println("2. Ver listado de alumnos");
            System.out.println("3. Modificación de alumno cargado");
            System.out.println("4. Borrar alumno");
            System.out.println("6. Listar materias y horarios");
            System.out.println("7. Cargar las notas de los trimestres");
            //aquí se usa el objeto scanner
            int opcion = scanner.nextInt();
            scanner.nextLine();
            // se elige una estructura switch para la parte principal del código, en pro de estructuras como if else
            switch (opcion) {
                case 1:
                    //declaramos la variable que almacena la respuesta del usuario necesaria para este case
                    String respuesta;
                    do {
                        //se informa al usuario si el listado de alumnos está vacío
                        if (notasEstudiantes.isEmpty()) {
                            System.out.println("No hay alumnos cargados.");
                        } else {
                            //si hay alumnos, muestra el listado de los mismos
                            System.out.println("Los alumnos ingresados son: " + notasEstudiantes.keySet());
                        }
                        System.out.println("Ingrese el nombre del alumno: ");
                        String nombreAlumno = scanner.nextLine();
                        //las siguientes líneas añaden al alumno si no está en la lista e informan si fue agregado con éxito
                        if (!notasEstudiantes.containsKey(nombreAlumno)) {
                            notasEstudiantes.put(nombreAlumno, new HashMap<>());
                        }
                        System.out.println("Alumno agregado con éxito.");
                        //da la opción de cargar un nuevo alumno sin necesidad de comenzar desde el menú inicial
                        System.out.println("¿Deseas cargar un nuevo alumno? (s/n)");
                        respuesta = scanner.nextLine();
                    } while (respuesta.equalsIgnoreCase("s"));
                    break;
                //vease los comentarios del anterior
                case 2:
                    if (notasEstudiantes.isEmpty()) {
                        System.out.println("No hay alumnos cargados.");
                    } else {
                        System.out.println("Los alumnos ingresados son: " + notasEstudiantes.keySet());
                    }
                    break;

                case 3:
                    //comienzo como los case anteriores
                    if (notasEstudiantes.isEmpty()) {
                        System.out.println("No hay alumnos cargados.");
                    } else {
                        do {
                            System.out.println("Los alumnos ingresados son: " + notasEstudiantes.keySet());
                            //a través de scanner se solicita ingresar el alumno a modificar
                            System.out.println("Ingrese el nombre del alumno que desea modificar: ");
                            String nombreModificar = scanner.nextLine();
                            //se verifica si el alumno está en el listado creado en él case 1
                            if (notasEstudiantes.containsKey(nombreModificar)) {
                                //se pide el nuevo nombre, se remueve el anterior y finalmente se agrega el nuevo nombre del alumno solicitado
                                System.out.println("Ingrese el nuevo nombre del alumno: ");
                                String nuevoNombre = scanner.nextLine();
                                HashMap<String, int[]> notas = notasEstudiantes.get(nombreModificar);
                                notasEstudiantes.remove(nombreModificar);
                                notasEstudiantes.put(nuevoNombre, notas);
                                System.out.println("Nombre actualizado con éxito.");
                            } else {
                                //se informa en el siguiente mensaje si el alumno no está en el listado
                                System.out.println("Alumno no encontrado. Verifique el nombre ingresado.");
                            }
                            //se habilita el poder modificar más alumnos sin salir al menú principal
                            System.out.println("¿Desea modificar otro alumno? (s/n): ");
                            respuesta = scanner.nextLine();
                        } while (respuesta.equalsIgnoreCase("s"));
                    }
                    break;


                case 4:
                    String respuestaEliminar;
                    if (notasEstudiantes.isEmpty()) {
                        System.out.println("No hay alumnos cargados.");
                    } else {
                        do {
                            System.out.println("Los alumnos ingresados son: " + notasEstudiantes.keySet());
                            //la diferencia con el case 3,es que aquí solo se identifica el alumno a eliminar y se remueve del HashMap notasEstudiantes
                            System.out.println("Ingrese el nombre del alumno que desea eliminar: ");
                            String nombreAEliminar = scanner.nextLine();
                            if (notasEstudiantes.containsKey(nombreAEliminar)) {
                                notasEstudiantes.remove(nombreAEliminar);
                                System.out.println(nombreAEliminar + " ha sido eliminado de la lista.");
                            } else {
                                System.out.println("Alumno no encontrado. Verifique el nombre ingresado.");
                            }
                            System.out.println("¿Desea eliminar otro alumno? (s/n)");
                            respuestaEliminar = scanner.nextLine();
                        } while (respuestaEliminar.equalsIgnoreCase("s"));
                    }
                    break;

                case 6:
                    //se agregan las materias solicitadas en la descripción de la actividad en el HashMap materiasHorarios
                    materiasHorarios.put("Teleinformática", "Lunes 19 a 22hs");
                    materiasHorarios.put("Programación Web", "Martes 19 a 22 hs");
                    materiasHorarios.put("Arquitectura del Computador", "Miércoles 19 a 22 hs");
                    materiasHorarios.put("Diseño y Administración de Base de Datos", "Jueves 19 a 22 hs");
                    materiasHorarios.put("Inteligencia Artificial", "Viernes de 19 a 22 hs");
                    //se imprime el listado presente de materias y horarios precargados
                    System.out.println("Materias y Horarios:");
                    for (Map.Entry<String, String> entry : materiasHorarios.entrySet()) {
                        System.out.println("Materia: " + entry.getKey() + ", Horario: " + entry.getValue());
                    }

                    String respuestaMateria;
                    do {
                        //se cargan los nombres y horarios de la materia que se desea agregar
                        System.out.println("Ingrese el nombre de la materia: ");
                        String nombreMateria = scanner.nextLine();
                        System.out.println("Ingrese el horario de la materia (por ejemplo, 'Lunes 10:00 AM' o 'Jueves de 10 a 12 hs): ");
                        String horarioMateria = scanner.nextLine();

                        // Añadimos la nueva materia y su horario a nuestro HashMap

                        materiasHorarios.put(nombreMateria, horarioMateria);
                        System.out.println("Materia agregada con éxito.");

                        System.out.println("¿Desea cargar otra materia? (s/n): ");
                        respuestaMateria = scanner.nextLine();
                    } while (respuestaMateria.equalsIgnoreCase("s"));

                    System.out.println("Materias agregadas con éxito.");

                    //se muestra un listado de como queda el listado de materias y horarios

                    System.out.println("Materias y Horarios:");
                    for (Map.Entry<String, String> entry : materiasHorarios.entrySet()) {
                        System.out.println("Materia: " + entry.getKey() + ", Horario: " + entry.getValue());
                    }
                    break;

                case 7:
                    String respuestaNotas;
                    //vease case 2
                    do {
                        System.out.println("Los alumnos ingresados son: " + notasEstudiantes.keySet());
                        //ingresamos el nombre del alumno al que vamos a cargar las notas
                        System.out.println("Ingrese Nombre del Alumno: ");
                        String nombreEstudiante = scanner.nextLine();

                        //creamos un array que almacene las notas que vamos a pedir que carguen

                        int[] notas = new int[NUM_TRIMESTRES];

                        //mostramos a continuación las materias a las cuales puede cargar las notas y pedimos que el usuario elija

                        System.out.println("Las materias cargadas son: " + materiasHorarios.keySet());
                        System.out.println("¿Las notas de qué materia va a cargar?");
                        String nombreMateria = scanner.nextLine();

                        //aquí solicitamos que el usuario cargue las notas

                        for (int i = 0; i < NUM_TRIMESTRES; i++) {
                            System.out.println("Ingrese la nota del trimestre " + (i + 1) + ": ");
                            notas[i] = scanner.nextInt();
                        }
                        //obtenemos las notas previas que puede haber tenido el alumno y luego se agregan las nuevas notas
                        HashMap<String, int[]> notasEstudiante = notasEstudiantes.getOrDefault(nombreEstudiante, new HashMap<>());
                        notasEstudiante.put(nombreMateria, notas);


                        notasEstudiantes.put(nombreEstudiante, notasEstudiante); // esta línea actualiza las notas del alumno en el HashMap de notasEstudiantes
                        //con el método definido al principio calculamos el promedio de las notas introducidas
                        float promedio = calcularPromedio(notas);
                        System.out.println("\nAlumno: " + nombreEstudiante);
                        //a partir del resultado del promedio se informa al usuario si el usuario aprueba, rinde final o recursa
                        if (promedio >= 7 && promedio <= 10) {
                            System.out.println("El alumno " + nombreEstudiante + " aprueba la materia " + nombreMateria);
                        } else if (promedio >= 4 && promedio <= 6) {
                            System.out.println("El alumno " + nombreEstudiante + " debe rendir examen final de la materia " + nombreMateria);
                        } else if (promedio >= 1 && promedio <= 3) {
                            System.out.println("El alumno " + nombreEstudiante + " recursa la materia " + nombreMateria);
                        } else {
                            System.out.println("Opción no válida.");
                        }

                        respuestaNotas = scanner.nextLine();
                    } while (respuestaNotas.equalsIgnoreCase("s"));
                    break;

            }
            //opción de todos los cases para continuar el programa
            System.out.println("¿Desea continuar en el programa? (s/n): ");
            continuarEleccion = scanner.nextLine();

        } while ("s".equalsIgnoreCase(continuarEleccion));

        System.out.println("El programa ha sido cerrado.");
    }
}